const state = {
  symbols: [],
};

const TIMEFRAMES = ["1m", "5m", "15m", "1h", "1d"];

function initTimeframes() {
  const container = document.querySelector(`.timeframe-group[data-scope="predict"]`);
  TIMEFRAMES.forEach((timeframe) => {
    const button = document.createElement("button");
    button.className = `timeframe-button${timeframe === state.predictTimeframe ? " active" : ""}`;
    button.type = "button";
    button.textContent = timeframe;
    button.addEventListener("click", () => {
      container.querySelectorAll(".timeframe-button").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      state.predictTimeframe = timeframe;
    });
    container.appendChild(button);
  });
}

function renderMetrics(containerId, candle) {
  const container = document.getElementById(containerId);
  if (!candle) {
    container.innerHTML = "";
    return;
  }

  const metrics = [
    ["Open", candle.open],
    ["High", candle.high],
    ["Low", candle.low],
    ["Close", candle.close],
  ];

  container.innerHTML = metrics.map(([label, value]) => `
    <article class="metric-card">
      <span>${label}</span>
      <strong>${Number(value).toFixed(2)}</strong>
    </article>
  `).join("");
}

async function loadSupportedStocks() {
  const select = document.getElementById("predict-symbol");
  const badge = document.getElementById("supported-count");

  try {
    const response = await fetch("/api/stocks");
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.detail || "Unable to load available stock models.");

    state.symbols = payload.symbols || [];
    select.innerHTML = state.symbols.map((symbol) => `
      <option value="${symbol}" ${symbol === payload.default_symbol ? "selected" : ""}>${symbol}</option>
    `).join("");

    badge.textContent = `${state.symbols.length} Stock Models Ready`;
  } catch (error) {
    badge.textContent = "Model list unavailable";
    select.innerHTML = `<option value="RELIANCE.NS">RELIANCE.NS</option>`;
  }
}

async function handlePrediction() {
  const fileInput = document.getElementById("predict-file");
  const status = document.getElementById("predict-status");
  const result = document.getElementById("predict-result");
  const symbol = document.getElementById("predict-symbol").value || "RELIANCE.NS";

  if (!fileInput.files.length) {
    result.innerHTML = `<p class="muted">Please choose a chart image first.</p>`;
    return;
  }

  const body = new FormData();
  body.append("file", fileInput.files[0]);
  body.append("symbol", symbol);
  body.append("use_lstm", true);

  status.textContent = "Running";

  try {
    const response = await fetch("/api/predict", { method: "POST", body });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.detail || payload.error?.message || "Prediction failed.");

    const pattern = payload.data.pattern;
    const signal = payload.data.signal;
    const metadata = payload.metadata;
    const signalClass = signal.label.toLowerCase();
    const modelPath = metadata.model_enhancements?.attached_model_path || "Attached stock model";

    const topPatternText = `${pattern.label} (${(pattern.confidence * 100).toFixed(2)}%)`;
    const fallbackNote = metadata.using_fallback_data ? ' (Using fallback data - may not be current)' : '';
    const sourceNote = metadata.market_data_source ? `Source: ${metadata.market_data_source}` : "";

    result.innerHTML = `
      <article class="result-box ${signalClass}">
        <strong>Signal: ${signal.label}</strong>
        <p>Confidence: ${(signal.confidence * 100).toFixed(2)}%</p>
        <p>Pattern: ${topPatternText}</p>
        <p>${sourceNote}</p>
        <p>Stock: ${metadata.instrument}</p>
        <p>Model: ${modelPath}</p>
        <p>Latest Candle Time: ${metadata.latest_candle?.time || "N/A"}${fallbackNote}</p>
      </article>
    `;
    renderMetrics("predict-ohlc", metadata.latest_candle);
  } catch (error) {
    result.innerHTML = `<article class="result-box sell"><strong>Error</strong><p>${error.message}</p></article>`;
    renderMetrics("predict-ohlc", null);
  } finally {
    status.textContent = "Ready";
  }
}

function initActions() {
  document.getElementById("predict-submit").addEventListener("click", handlePrediction);
}

window.addEventListener("DOMContentLoaded", async () => {
  initActions();
  await loadSupportedStocks();
});
