import asyncio
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import List, Tuple, Optional
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from app.config import config

logger = logging.getLogger(__name__)


def _get_yfinance():
    try:
        import yfinance as yf
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "yfinance is required for stock market data. Install it with `pip install yfinance`."
        ) from exc
    cache_dir = Path(config.DATA_DIR) / "yfinance-cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    if hasattr(yf, "set_tz_cache_location"):
        yf.set_tz_cache_location(os.fspath(cache_dir))
    return yf


class StockDataService:
    """Fetch recent stock OHLCV data from yfinance and prepare stock-LSTM features."""

    TIMEFRAME_CONFIG = {
        "1m": {"interval": "1m", "period": "7d"},
        "5m": {"interval": "5m", "period": "60d"},
        "15m": {"interval": "15m", "period": "60d"},
        "1h": {"interval": "60m", "period": "730d"},
        "1d": {"interval": "1d", "period": "max"},
    }
    IST = ZoneInfo("Asia/Kolkata")

    def __init__(self):
        self.last_fetch_source = "yfinance"
        self._cache_dir = Path(config.DATA_DIR) / "ohlcv-cache"
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_ttl = 3600  # 1 hour cache TTL for market data
        self.using_fallback_data = False

    def _get_cache_key(self, symbol: str, timeframe: str, limit: int) -> str:
        """Generate a cache key for the OHLCV data."""
        key_data = f"{symbol}:{timeframe}:{limit}"
        return hashlib.md5(key_data.encode()).hexdigest()

    def _get_cache_path(self, cache_key: str) -> Path:
        """Get the file path for cached data."""
        return self._cache_dir / f"{cache_key}.json"

    def _is_cache_valid(self, cache_path: Path) -> bool:
        """Check if cache file exists and is not expired."""
        if not cache_path.exists():
            return False
        return (time.time() - cache_path.stat().st_mtime) < self._cache_ttl

    def _load_from_cache(self, cache_key: str, skip_cache: bool = False) -> Optional[Tuple[List[float], List[float], List[float], List[float], List[float], List[str]]]:
        """Load OHLCV data from cache if valid."""
        if skip_cache:
            return None
        cache_path = self._get_cache_path(cache_key)
        if not self._is_cache_valid(cache_path):
            return None

        try:
            with open(cache_path, 'r') as f:
                data = json.load(f)
            self.using_fallback_data = data.get('is_fallback', False)
            logger.info(f"Loaded cached data for key {cache_key} (fallback: {self.using_fallback_data})")
            return (
                data['opens'],
                data['highs'],
                data['lows'],
                data['closes'],
                data['volumes'],
                data['times']
            )
        except (json.JSONDecodeError, KeyError, FileNotFoundError) as e:
            logger.warning(f"Failed to load cache for {cache_key}: {e}")
            return None

    def _generate_fallback_data(self, symbol: str, timeframe: str, limit: int) -> Tuple[List[float], List[float], List[float], List[float], List[float], List[str]]:
        """Generate synthetic OHLCV data for testing when API fails."""
        import datetime
        
        logger.warning(f"Generating fallback data for {symbol} due to API rate limiting")
        
        # Generate synthetic data based on typical stock patterns
        base_price = 1000.0 if symbol in ['RELIANCE.NS', 'TCS.NS', 'INFY.NS'] else 500.0
        
        # Generate timestamps for the last 'limit' periods
        now = datetime.datetime.now(self.IST)
        times = []
        
        if timeframe == '1d':
            # Daily data
            for i in range(limit):
                dt = now - datetime.timedelta(days=limit-i-1)
                times.append(dt.isoformat())
        elif timeframe in ['1h', '5m', '15m']:
            # Intraday data
            minutes_per_period = {'1h': 60, '15m': 15, '5m': 5}[timeframe]
            for i in range(limit):
                dt = now - datetime.timedelta(minutes=minutes_per_period * (limit-i-1))
                times.append(dt.isoformat())
        
        # Generate OHLCV data with some realistic volatility
        opens, highs, lows, closes, volumes = [], [], [], [], []
        current_price = base_price
        
        for i in range(limit):
            # Add some random walk
            change = np.random.normal(0, 0.02)  # 2% volatility
            open_price = current_price
            close_price = open_price * (1 + change)
            
            # Generate OHLC
            high_price = max(open_price, close_price) * (1 + abs(np.random.normal(0, 0.005)))
            low_price = min(open_price, close_price) * (1 - abs(np.random.normal(0, 0.005)))
            
            opens.append(round(open_price, 2))
            highs.append(round(high_price, 2))
            lows.append(round(low_price, 2))
            closes.append(round(close_price, 2))
            volumes.append(int(np.random.uniform(10000, 100000)))  # Random volume
            
            current_price = close_price
        
        return opens, highs, lows, closes, volumes, times

    def _save_to_cache(self, cache_key: str, opens: List[float], highs: List[float], lows: List[float],
                      closes: List[float], volumes: List[float], times: List[str], is_fallback: bool = False) -> None:
        """Save OHLCV data to cache."""
        cache_path = self._get_cache_path(cache_key)
        data = {
            'opens': opens,
            'highs': highs,
            'lows': lows,
            'closes': closes,
            'volumes': volumes,
            'times': times,
            'is_fallback': is_fallback
        }
        try:
            with open(cache_path, 'w') as f:
                json.dump(data, f)
        except Exception as e:
            logger.warning(f"Failed to save cache for {cache_key}: {e}")

    async def fetch_ohlcv(
        self,
        symbol: str,
        timeframe: str = "5m",
        limit: int = 60,
        skip_cache: bool = False
    ) -> Tuple[List[float], List[float], List[float], List[float], List[float], List[str]]:
        if timeframe not in config.VALID_TIMEFRAMES:
            raise ValueError(
                f"Invalid timeframe '{timeframe}'. Valid values: {config.VALID_TIMEFRAMES}"
            )

        return await asyncio.to_thread(self._fetch_ohlcv_sync, symbol, timeframe, limit, skip_cache)

    def _fetch_ohlcv_sync(
        self,
        symbol: str,
        timeframe: str,
        limit: int,
        skip_cache: bool = False
    ) -> Tuple[List[float], List[float], List[float], List[float], List[float], List[str]]:
        """Fetch OHLCV data with retry logic for rate limiting and caching."""
        cache_key = self._get_cache_key(symbol, timeframe, limit)

        # Try to load from cache first
        cached_data = self._load_from_cache(cache_key, skip_cache)
        if cached_data is not None:
            logger.info(f"Loaded {symbol} {timeframe} data from cache")
            return cached_data

        # Cache miss, fetch from API with retry logic
        max_retries = config.YFINANCE_MAX_RETRIES
        base_delay = config.YFINANCE_BASE_DELAY

        for attempt in range(max_retries):
            try:
                yf = _get_yfinance()
                ticker = yf.Ticker(symbol)
                cfg = self.TIMEFRAME_CONFIG[timeframe]
                history = ticker.history(
                    period=cfg["period"],
                    interval=cfg["interval"],
                    auto_adjust=False,
                    actions=False,
                )

                if history.empty:
                    raise ValueError(f"No OHLCV history returned for {symbol} on timeframe {timeframe}.")

                if "Adj Close" in history.columns and history["Adj Close"].notna().any():
                    history["Close"] = history["Adj Close"]

                frame = history[["Open", "High", "Low", "Close", "Volume"]].copy()
                frame = frame.dropna(subset=["Close"]).tail(limit)

                if len(frame) < limit:
                    raise ValueError(
                        f"Only {len(frame)} candles are available for {symbol} on {timeframe}; {limit} are required."
                    )

                if getattr(frame.index, "tz", None) is None:
                    frame.index = frame.index.tz_localize(self.IST)
                else:
                    frame.index = frame.index.tz_convert(self.IST)

                self.last_fetch_source = "yfinance"
                opens = frame["Open"].astype(float).round(4).tolist()
                highs = frame["High"].astype(float).round(4).tolist()
                lows = frame["Low"].astype(float).round(4).tolist()
                closes = frame["Close"].astype(float).round(4).tolist()
                volumes = frame["Volume"].fillna(0).astype(float).round(4).tolist()
                times = [timestamp.isoformat() for timestamp in frame.index]

                # Save to cache
                self._save_to_cache(cache_key, opens, highs, lows, closes, volumes, times, is_fallback=False)
                self.using_fallback_data = False

                return opens, highs, lows, closes, volumes, times

                # Save to cache
                self._save_to_cache(cache_key, opens, highs, lows, closes, volumes, times)

                return opens, highs, lows, closes, volumes, times

            except Exception as exc:
                error_msg = str(exc).lower()
                is_rate_limited = (
                    "too many requests" in error_msg or
                    "rate limit" in error_msg or
                    "429" in error_msg
                )

                if is_rate_limited and attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt)  # Exponential backoff
                    logger.warning(f"Rate limited for {symbol}, attempt {attempt + 1}/{max_retries}. Retrying in {delay}s...")
                    time.sleep(delay)
                    continue
                else:
                    # If all retries failed, try to use fallback data for supported symbols
                    if symbol in ['HDFCBANK.NS', 'ICICIBANK.NS', 'INFY.NS', 'RELIANCE.NS', 'TCS.NS']:
                        logger.warning(f"All API attempts failed for {symbol}, using fallback data")
                        fallback_data = self._generate_fallback_data(symbol, timeframe, limit)
                        # Cache the fallback data
                        self._save_to_cache(cache_key, *fallback_data, is_fallback=True)
                        self.using_fallback_data = True
                        return fallback_data
                    else:
                        raise RuntimeError(f"Failed to fetch stock data for {symbol}. {exc}") from exc

        # This should never be reached, but just in case
        raise RuntimeError(f"Failed to fetch stock data for {symbol} after {max_retries} attempts.")

    def prepare_lstm_features(self, closes: List[float]) -> np.ndarray:
        """Create a `(sequence_length, 1)` return tensor for the stock LSTM."""
        close_series = pd.Series(closes, dtype=np.float32)
        returns = close_series.pct_change().dropna().astype(np.float32)
        if len(returns) < config.LSTM_SEQUENCE_LENGTH:
            raise ValueError(
                f"Need at least {config.LSTM_SEQUENCE_LENGTH + 1} closes to build a "
                f"{config.LSTM_SEQUENCE_LENGTH}-step return sequence."
            )

        sequence = returns.tail(config.LSTM_SEQUENCE_LENGTH).to_numpy().reshape(-1, 1)
        return np.nan_to_num(sequence, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)

    def trim_candles(
        self,
        opens: List[float],
        highs: List[float],
        lows: List[float],
        closes: List[float],
        volumes: List[float],
        times: List[str],
        limit: int,
    ):
        return (
            opens[-limit:],
            highs[-limit:],
            lows[-limit:],
            closes[-limit:],
            volumes[-limit:],
            times[-limit:],
        )

    def latest_candle(
        self,
        opens: List[float],
        highs: List[float],
        lows: List[float],
        closes: List[float],
        volumes: List[float],
        times: List[str],
    ) -> dict:
        return {
            "time": times[-1],
            "open": round(opens[-1], 2),
            "high": round(highs[-1], 2),
            "low": round(lows[-1], 2),
            "close": round(closes[-1], 2),
            "volume": round(volumes[-1], 2),
        }

    def build_candles(
        self,
        opens: List[float],
        highs: List[float],
        lows: List[float],
        closes: List[float],
        volumes: List[float],
        times: List[str],
    ) -> List[dict]:
        return [
            {
                "time": timestamp,
                "open": round(open_price, 2),
                "high": round(high_price, 2),
                "low": round(low_price, 2),
                "close": round(close_price, 2),
                "volume": round(volume, 2),
            }
            for open_price, high_price, low_price, close_price, volume, timestamp in zip(
                opens, highs, lows, closes, volumes, times
            )
        ]

    def summarize_market_data(
        self,
        highs: List[float],
        lows: List[float],
        closes: List[float],
        volumes: List[float],
    ) -> dict:
        closes_arr = np.array(closes, dtype=np.float32)
        volumes_arr = np.array(volumes, dtype=np.float32)

        price_change = float(closes_arr[-1] - closes_arr[-2]) if len(closes_arr) > 1 else 0.0
        price_change_pct = (
            float((price_change / closes_arr[-2]) * 100)
            if len(closes_arr) > 1 and closes_arr[-2] != 0
            else 0.0
        )

        return {
            "current_price": round(float(closes_arr[-1]), 2),
            "price_change": round(price_change, 2),
            "price_change_pct": round(price_change_pct, 2),
            "short_term_trend": (
                "Bullish"
                if len(closes_arr) > 5 and closes_arr[-1] > closes_arr[-5]
                else "Bearish"
                if len(closes_arr) > 5 and closes_arr[-1] < closes_arr[-5]
                else "Neutral"
            ),
            "range": round(float(max(highs) - min(lows)), 2),
            "average_volume": round(float(volumes_arr.mean()), 2),
        }


NiftyDataService = StockDataService
