from app.services.nifty_data_service import NiftyDataService


class MarketDataService(NiftyDataService):
    """
    Backward-compatible alias for the Nifty-only market data service.

    The project no longer uses Binance/Polygon. All OHLCV fetches route through
    yfinance with `^NSEI` and support the fixed timeframe set used by the UI.
    """

    pass