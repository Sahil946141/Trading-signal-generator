from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
import os
import tempfile
import time
import logging
import numpy as np
from uuid import uuid4

# Import all services and models
from app.services.image_preprocess import ImagePreprocessor
from app.models.cnn_pattern_model import PatternDetectionModel
from app.models.lstm_signal_model import HybridSignalModel
from app.services.market_data_service import MarketDataService
from app.services.response_builder import ResponseBuilder
from app.utils.label_encoder import PatternLabelEncoder
from app.config import config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["predictions"])

# Global service instances (initialize on startup)
_services = {}

def init_services():
    """Initialize all services on app startup."""
    global _services
    
    _services["image_preprocessor"] = ImagePreprocessor(target_size=(224, 224), is_training=False)
    _services["pattern_model"] = PatternDetectionModel(
        model_path=config.PATTERN_MODEL_PATH,
        use_improved_model=True  # Use enhanced CNN model
    )
    _services["signal_model"] = HybridSignalModel(
        sequence_length=60,  # Increased sequence length
        lstm_hidden=128,     # Increased hidden size
        lstm_layers=3,       # More layers
        dropout=0.2          # Optimized dropout
    )
    if os.path.exists(config.LSTM_MODEL_PATH):
        _services["signal_model"].load(config.LSTM_MODEL_PATH)
    
    _services["market_data_service"] = MarketDataService(
        api_key=config.MARKET_API_KEY,
        api_type=config.MARKET_API_TYPE,
        base_url=config.MARKET_API_BASE_URL
    )
    
    _services["label_encoder"] = PatternLabelEncoder(
        PatternDetectionModel.PATTERN_CLASSES
    )
    
    logger.info("All enhanced services initialized successfully")

@router.post("/predict")
async def predict_signal(
    file: UploadFile = File(...),
    instrument: str = config.DEFAULT_INSTRUMENT,
    timeframe: str = config.DEFAULT_TIMEFRAME,
    use_lstm: bool = config.USE_LSTM
):
    """
    Main prediction endpoint.
    
    Workflow:
    1. Validate and save uploaded image
    2. Detect pattern from image
    3. Fetch market data (OHLCV)
    4. Predict signal (LSTM or rule-based)
    5. Build and return response
    
    Args:
        file: Chart image file
        instrument: Trading symbol (NIFTY, SENSEX, BTCUSDT, etc.)
        timeframe: Candle interval (5m, 15m, 1h, etc.)
        use_lstm: Use LSTM model (True) or rule-based (False)
    
    Returns:
        JSON response with pattern and signal predictions
    """
    request_id = str(uuid4())[:8]
    start_time = time.time()
    
    temp_file = None
    
    try:
        # Get services
        img_preprocessor = _services["image_preprocessor"]
        pattern_model = _services["pattern_model"]
        signal_model = _services["signal_model"]
        market_data_service = _services["market_data_service"]
        label_encoder = _services["label_encoder"]
        
        # Validate file
        if not file.filename.lower().endswith(('.jpg', '.jpeg', '.png', '.gif')):
            raise HTTPException(
                status_code=400,
                detail="Invalid file type. Supported: JPG, PNG, GIF"
            )
        
        # Check file size
        contents = await file.read()
        if len(contents) > config.MAX_IMAGE_SIZE_MB * 1024 * 1024:
            raise HTTPException(
                status_code=400,
                detail=f"File too large. Max size: {config.MAX_IMAGE_SIZE_MB}MB"
            )
        
        # Save uploaded file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
            temp_file = tmp.name
            tmp.write(contents)
        
        logger.info(f"[{request_id}] Processing image for {instrument}")
        
        # Step 1: Preprocess image
        image_tensor = img_preprocessor.preprocess(temp_file)
        
        # Step 2: Detect pattern with enhanced accuracy
        # Use test-time augmentation for better results
        predictions = []
        
        # Standard prediction
        standard_result = pattern_model.predict(image_tensor)
        predictions.append(standard_result)
        
        # Test-time augmentation (if available)
        try:
            augmented_batch = img_preprocessor.create_test_time_augmentation(
                temp_file, num_augmentations=3
            )
            
            for i in range(augmented_batch.shape[0]):
                aug_tensor = augmented_batch[i:i+1]
                aug_result = pattern_model.predict(aug_tensor)
                predictions.append(aug_result)
            
            # Ensemble predictions for better accuracy
            pattern_result = _ensemble_predictions(predictions)
            logger.info(f"[{request_id}] Enhanced pattern detection: {pattern_result['pattern']} (ensemble of {len(predictions)})")
        except Exception as e:
            logger.warning(f"[{request_id}] Test-time augmentation failed: {e}, using standard prediction")
            pattern_result = standard_result
            logger.info(f"[{request_id}] Detected pattern: {pattern_result['pattern']}")
        
        # Step 3: Fetch enhanced market data with technical indicators
        try:
            opens, highs, lows, closes, volumes = await market_data_service.fetch_ohlcv(
                symbol=instrument,
                timeframe=timeframe,
                limit=60  # Increased for better LSTM context
            )
            
            # Prepare enhanced features with technical indicators
            enhanced_features = market_data_service.prepare_enhanced_features(
                opens, highs, lows, closes, volumes
            )
            
            current_price = closes[-1]
            logger.info(f"[{request_id}] Enhanced features prepared: {enhanced_features.shape}")
        except Exception as e:
            logger.error(f"[{request_id}] Market data fetch failed: {e}")
            raise HTTPException(
                status_code=503,
                detail=f"Unable to fetch market data for {instrument}. Please check symbol and try again."
            )
        
        # Step 4: Enhanced signal prediction
        if use_lstm:
            try:
                # Encode pattern
                pattern_encoded = label_encoder.encode(
                    pattern_result["pattern"],
                    pattern_result["pattern_confidence"]
                )
                
                # Enhanced LSTM prediction with technical indicators
                signal_result = signal_model.predict(pattern_encoded, enhanced_features)
                logger.info(f"[{request_id}] Enhanced LSTM signal: {signal_result['signal']} ({signal_result['confidence']:.2%})")
            except Exception as e:
                logger.error(f"[{request_id}] Enhanced LSTM prediction failed: {e}")
                raise HTTPException(
                    status_code=500,
                    detail="LSTM model prediction failed. Model may not be trained yet."
                )
        else:
            # Enhanced rule-based mapping with technical analysis
            signal_result = enhanced_rule_based_mapping(pattern_result["pattern"], enhanced_features)
            logger.info(f"[{request_id}] Enhanced rule-based signal: {signal_result['signal']}")
        
        # Step 5: Build enhanced response with technical analysis
        technical_summary = _calculate_technical_summary_from_features(enhanced_features)
        
        metadata = {
            "instrument": instrument,
            "timeframe": timeframe,
            "current_price": round(current_price, 2),
            "last_updated": time.time(),
            "model_enhancements": {
                "cnn_model": "Enhanced EfficientNet with attention",
                "lstm_model": "Bidirectional LSTM with technical indicators",
                "sequence_length": 60,
                "features_count": enhanced_features.shape[1] if enhanced_features is not None else 5,
                "test_time_augmentation": len(predictions) > 1 if 'predictions' in locals() else False
            },
            "technical_analysis": technical_summary
        }
        
        processing_time = (time.time() - start_time) * 1000
        response = ResponseBuilder.build_prediction_response(
            pattern_result=pattern_result,
            signal_result=signal_result,
            metadata=metadata,
            request_id=request_id,
            processing_time_ms=processing_time
        )
        
        logger.info(f"[{request_id}] Response sent in {processing_time:.0f}ms")
        return JSONResponse(content=response, status_code=200)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{request_id}] Prediction error: {str(e)}")
        error_response = ResponseBuilder.build_error_response(
            error_message=str(e),
            request_id=request_id
        )
        return JSONResponse(content=error_response, status_code=500)
    
    finally:
        # Cleanup temp file
        if temp_file and os.path.exists(temp_file):
            os.remove(temp_file)

def enhanced_rule_based_mapping(pattern: str, enhanced_features: np.ndarray = None) -> dict:
    """
    Enhanced rule-based signal mapping with technical analysis.
    
    Incorporates technical indicators for better accuracy.
    """
    # Base pattern rules
    base_rules = {
        "Double Bottom": {"signal": "BUY", "confidence": 0.75},
        "Double Top": {"signal": "SELL", "confidence": 0.75},
        "Head and Shoulders": {"signal": "SELL", "confidence": 0.80},
        "Inverse Head and Shoulders": {"signal": "BUY", "confidence": 0.80},
        "Triangle Ascending": {"signal": "BUY", "confidence": 0.70},
        "Triangle Descending": {"signal": "SELL", "confidence": 0.70},
        "Flag": {"signal": "BUY", "confidence": 0.65},
        "Wedge": {"signal": "HOLD", "confidence": 0.60},
        "Cup and Handle": {"signal": "BUY", "confidence": 0.75},
        "Consolidation": {"signal": "HOLD", "confidence": 0.55}
    }
    
    rule = base_rules.get(pattern, {"signal": "HOLD", "confidence": 0.50})
    
    # Enhance with technical analysis if available
    if enhanced_features is not None and enhanced_features.shape[0] > 0:
        try:
            # Extract technical indicators from enhanced features
            # Assuming features are [OHLCV + technical indicators]
            closes = enhanced_features[:, 3]  # Close prices
            
            # Simple technical analysis
            recent_trend = "bullish" if closes[-1] > closes[-10] else "bearish"
            momentum = (closes[-1] - closes[-5]) / closes[-5]
            
            # Adjust confidence based on technical analysis
            if rule["signal"] == "BUY" and recent_trend == "bullish" and momentum > 0:
                rule["confidence"] = min(0.95, rule["confidence"] + 0.15)
            elif rule["signal"] == "SELL" and recent_trend == "bearish" and momentum < 0:
                rule["confidence"] = min(0.95, rule["confidence"] + 0.15)
            elif rule["signal"] == "BUY" and recent_trend == "bearish":
                rule["confidence"] = max(0.30, rule["confidence"] - 0.20)
            elif rule["signal"] == "SELL" and recent_trend == "bullish":
                rule["confidence"] = max(0.30, rule["confidence"] - 0.20)
                
        except Exception as e:
            logger.warning(f"Technical analysis enhancement failed: {e}")
    
    # Calculate probabilities
    base_prob = rule["confidence"]
    other_prob = (1 - base_prob) / 2
    
    probabilities = {
        "BUY": base_prob if rule["signal"] == "BUY" else other_prob,
        "SELL": base_prob if rule["signal"] == "SELL" else other_prob,
        "HOLD": base_prob if rule["signal"] == "HOLD" else other_prob
    }
    
    return {
        "signal": rule["signal"],
        "confidence": rule["confidence"],
        "probabilities": probabilities
    }

def _ensemble_predictions(predictions: list) -> dict:
    """
    Ensemble multiple predictions for better accuracy.
    
    Args:
        predictions: List of prediction dictionaries
    
    Returns:
        Ensembled prediction dictionary
    """
    if len(predictions) == 1:
        return predictions[0]
    
    # Average probabilities
    all_probs = []
    for pred in predictions:
        probs = list(pred["probabilities"].values())
        all_probs.append(probs)
    
    avg_probs = np.mean(all_probs, axis=0)
    
    # Get ensemble prediction
    pattern_classes = list(predictions[0]["probabilities"].keys())
    best_idx = np.argmax(avg_probs)
    best_pattern = pattern_classes[best_idx]
    best_confidence = avg_probs[best_idx]
    
    # Create ensemble probabilities dict
    ensemble_probs = {
        pattern: prob for pattern, prob in zip(pattern_classes, avg_probs)
    }
    
    # Get top 5
    top5_indices = np.argsort(avg_probs)[-5:][::-1]
    top5 = [
        {
            "pattern": pattern_classes[idx],
            "confidence": avg_probs[idx]
        }
        for idx in top5_indices
    ]
    
    return {
        "pattern": best_pattern,
        "pattern_confidence": best_confidence,
        "probabilities": ensemble_probs,
        "top_5": top5
    }

def _calculate_technical_summary_from_features(enhanced_features: np.ndarray) -> dict:
    """Calculate technical analysis summary from enhanced features."""
    if enhanced_features is None or enhanced_features.shape[0] == 0:
        return {"status": "No technical data available"}
    
    try:
        # Extract basic OHLCV (first 5 columns)
        closes = enhanced_features[:, 3]
        volumes = enhanced_features[:, 4]
        
        # Calculate basic indicators
        current_price = closes[-1]
        price_change = closes[-1] - closes[-2] if len(closes) > 1 else 0
        price_change_pct = (price_change / closes[-2] * 100) if len(closes) > 1 and closes[-2] != 0 else 0
        
        # Trend analysis
        short_trend = "Bullish" if closes[-1] > closes[-5] else "Bearish" if len(closes) > 5 else "Neutral"
        long_trend = "Bullish" if closes[-1] > closes[-20] else "Bearish" if len(closes) > 20 else "Neutral"
        
        # Volume analysis
        avg_volume = np.mean(volumes[-10:]) if len(volumes) > 10 else np.mean(volumes)
        volume_trend = "High" if volumes[-1] > avg_volume * 1.2 else "Low" if volumes[-1] < avg_volume * 0.8 else "Normal"
        
        return {
            "current_price": round(current_price, 2),
            "price_change": round(price_change, 2),
            "price_change_pct": round(price_change_pct, 2),
            "short_term_trend": short_trend,
            "long_term_trend": long_trend,
            "volume_trend": volume_trend,
            "momentum": "Positive" if price_change > 0 else "Negative" if price_change < 0 else "Neutral"
        }
    except Exception as e:
        logger.warning(f"Technical summary calculation failed: {e}")
        return {"status": "Technical analysis failed", "error": str(e)}

def rule_based_mapping(pattern: str) -> dict:
    """
    Legacy rule-based signal mapping (kept for backward compatibility).
    """
    return enhanced_rule_based_mapping(pattern, None)



@router.get("/health")
async def health_check():
    """Enhanced health check endpoint."""
    return {
        "status": "healthy",
        "service": "enhanced-trading-signal-predictor",
        "services_initialized": len(_services) > 0,
        "model_enhancements": {
            "cnn_model": "EfficientNet with attention mechanism",
            "lstm_model": "Bidirectional LSTM with technical indicators",
            "features": [
                "Test-time augmentation",
                "Ensemble predictions", 
                "Technical indicators integration",
                "Enhanced sequence analysis (60 timesteps)",
                "Attention mechanism",
                "Advanced regularization"
            ]
        },
        "version": "2.0.0"
    }