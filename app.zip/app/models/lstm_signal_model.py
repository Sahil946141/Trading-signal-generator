import torch
import torch.nn as nn
import numpy as np
import logging
from pathlib import Path
import pandas as pd

logger = logging.getLogger(__name__)

class AttentionLayer(nn.Module):
    """Attention mechanism for LSTM outputs."""
    
    def __init__(self, hidden_size):
        super().__init__()
        self.attention = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.Tanh(),
            nn.Linear(hidden_size // 2, 1)
        )
    
    def forward(self, lstm_outputs):
        # lstm_outputs: (batch, seq_len, hidden_size)
        attention_weights = self.attention(lstm_outputs)  # (batch, seq_len, 1)
        attention_weights = torch.softmax(attention_weights, dim=1)
        
        # Weighted sum
        context = torch.sum(lstm_outputs * attention_weights, dim=1)  # (batch, hidden_size)
        return context, attention_weights

class EnhancedLSTMModel(nn.Module):
    """
    Enhanced LSTM model for price prediction with technical indicators.
    
    Improvements:
    - Bidirectional LSTM
    - Attention mechanism
    - Technical indicators integration
    - Multi-timeframe analysis
    - Residual connections
    """
    
    def __init__(
        self,
        input_features: int = 20,  # OHLCV + technical indicators
        sequence_length: int = 60,  # Longer sequence for better patterns
        lstm_hidden: int = 128,
        lstm_layers: int = 3,
        dropout: float = 0.2,
        num_classes: int = 3,  # BUY, SELL, HOLD
        device: str = None
    ):
        super().__init__()
        
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.input_features = input_features
        self.sequence_length = sequence_length
        self.lstm_hidden = lstm_hidden
        
        # Input normalization
        self.input_norm = nn.LayerNorm(input_features)
        
        # Bidirectional LSTM layers
        self.lstm1 = nn.LSTM(
            input_size=input_features,
            hidden_size=lstm_hidden,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
            dropout=0
        )
        
        self.lstm2 = nn.LSTM(
            input_size=lstm_hidden * 2,  # Bidirectional
            hidden_size=lstm_hidden,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
            dropout=0
        )
        
        self.lstm3 = nn.LSTM(
            input_size=lstm_hidden * 2,
            hidden_size=lstm_hidden,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
            dropout=0
        )
        
        # Attention mechanism
        self.attention = AttentionLayer(lstm_hidden * 2)
        
        # Dropout layers
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(lstm_hidden * 2, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout / 2),
            nn.Linear(128, num_classes)
        )
        
        # Initialize weights
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Initialize LSTM and linear layer weights."""
        for name, param in self.named_parameters():
            if 'weight_ih' in name:
                nn.init.xavier_uniform_(param.data)
            elif 'weight_hh' in name:
                nn.init.orthogonal_(param.data)
            elif 'bias' in name:
                param.data.fill_(0)
                # Set forget gate bias to 1
                if 'bias_ih' in name:
                    n = param.size(0)
                    param.data[n//4:n//2].fill_(1)
    
    def forward(self, x):
        # x: (batch, seq_len, features)
        batch_size = x.size(0)
        
        # Input normalization
        x = self.input_norm(x)
        
        # LSTM layers with residual connections
        lstm1_out, _ = self.lstm1(x)
        lstm1_out = self.dropout1(lstm1_out)
        
        lstm2_out, _ = self.lstm2(lstm1_out)
        lstm2_out = self.dropout2(lstm2_out)
        
        # Residual connection
        lstm2_out = lstm2_out + lstm1_out
        
        lstm3_out, _ = self.lstm3(lstm2_out)
        lstm3_out = self.dropout3(lstm3_out)
        
        # Another residual connection
        lstm3_out = lstm3_out + lstm2_out
        
        # Attention mechanism
        context, attention_weights = self.attention(lstm3_out)
        
        # Classification
        logits = self.classifier(context)
        
        return logits, attention_weights

class TechnicalIndicators:
    """Calculate technical indicators for enhanced features."""
    
    @staticmethod
    def calculate_sma(prices, window):
        """Simple Moving Average."""
        return pd.Series(prices).rolling(window=window).mean().fillna(0).values
    
    @staticmethod
    def calculate_ema(prices, window):
        """Exponential Moving Average."""
        return pd.Series(prices).ewm(span=window).mean().fillna(0).values
    
    @staticmethod
    def calculate_rsi(prices, window=14):
        """Relative Strength Index."""
        prices = pd.Series(prices)
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi.fillna(50).values
    
    @staticmethod
    def calculate_macd(prices, fast=12, slow=26, signal=9):
        """MACD indicator."""
        prices = pd.Series(prices)
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        macd = ema_fast - ema_slow
        signal_line = macd.ewm(span=signal).mean()
        histogram = macd - signal_line
        return macd.fillna(0).values, signal_line.fillna(0).values, histogram.fillna(0).values
    
    @staticmethod
    def calculate_bollinger_bands(prices, window=20, num_std=2):
        """Bollinger Bands."""
        prices = pd.Series(prices)
        sma = prices.rolling(window=window).mean()
        std = prices.rolling(window=window).std()
        upper = sma + (std * num_std)
        lower = sma - (std * num_std)
        return upper.fillna(0).values, lower.fillna(0).values
    
    @staticmethod
    def calculate_stochastic(highs, lows, closes, k_window=14, d_window=3):
        """Stochastic Oscillator."""
        highs = pd.Series(highs)
        lows = pd.Series(lows)
        closes = pd.Series(closes)
        
        lowest_low = lows.rolling(window=k_window).min()
        highest_high = highs.rolling(window=k_window).max()
        
        k_percent = 100 * ((closes - lowest_low) / (highest_high - lowest_low))
        d_percent = k_percent.rolling(window=d_window).mean()
        
        return k_percent.fillna(50).values, d_percent.fillna(50).values

class HybridSignalModel(nn.Module):
    """
    Enhanced hybrid model combining pattern recognition and advanced sequence analysis.
    
    Architecture:
    - Branch A: Pattern encoding (one-hot + confidence)
    - Branch B: Enhanced LSTM with technical indicators
    - Fusion: Advanced fusion with attention
    """
    
    SIGNAL_CLASSES = ["BUY", "SELL", "HOLD"]
    
    def __init__(
        self,
        num_patterns: int = 10,
        sequence_length: int = 60,  # Increased from 30
        ohlcv_features: int = 5,
        technical_features: int = 15,  # Additional technical indicators
        lstm_hidden: int = 128,  # Increased from 64
        lstm_layers: int = 3,  # Increased from 2
        dropout: float = 0.2,  # Reduced from 0.3
        device: str = None
    ):
        """
        Initialize enhanced hybrid signal model.
        
        Args:
            num_patterns: Number of pattern classes
            sequence_length: Length of candle sequence (60)
            ohlcv_features: Number of OHLCV features (5)
            technical_features: Number of technical indicator features (15)
            lstm_hidden: Hidden size of LSTM
            lstm_layers: Number of LSTM layers
            dropout: Dropout probability
            device: torch device (cuda/cpu)
        """
        super().__init__()
        
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.num_patterns = num_patterns
        self.sequence_length = sequence_length
        self.total_features = ohlcv_features + technical_features
        
        # Technical indicators calculator
        self.tech_indicators = TechnicalIndicators()
        
        # ==== Branch A: Enhanced Pattern Features ====
        self.pattern_embedding = nn.Sequential(
            nn.Linear(num_patterns + 1, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 32),
            nn.ReLU()
        )
        
        # ==== Branch B: Enhanced LSTM ====
        self.lstm_model = EnhancedLSTMModel(
            input_features=self.total_features,
            sequence_length=sequence_length,
            lstm_hidden=lstm_hidden,
            lstm_layers=lstm_layers,
            dropout=dropout,
            num_classes=lstm_hidden,  # Output features for fusion
            device=device
        )
        
        # ==== Advanced Fusion ====
        fusion_input_size = 32 + lstm_hidden  # Pattern + LSTM features
        
        self.fusion_attention = nn.Sequential(
            nn.Linear(fusion_input_size, fusion_input_size // 2),
            nn.Tanh(),
            nn.Linear(fusion_input_size // 2, fusion_input_size),
            nn.Sigmoid()
        )
        
        self.fusion_layers = nn.Sequential(
            nn.Linear(fusion_input_size, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(dropout / 2),
            nn.Linear(64, len(self.SIGNAL_CLASSES))
        )
        
        logger.info("Enhanced HybridSignalModel initialized")
    
    def _prepare_technical_features(self, ohlcv_sequence: np.ndarray) -> np.ndarray:
        """
        Calculate technical indicators and combine with OHLCV.
        
        Args:
            ohlcv_sequence: OHLCV data (seq_len, 5)
        
        Returns:
            Enhanced features (seq_len, 20)
        """
        opens, highs, lows, closes, volumes = ohlcv_sequence.T
        
        # Calculate technical indicators
        sma_5 = self.tech_indicators.calculate_sma(closes, 5)
        sma_10 = self.tech_indicators.calculate_sma(closes, 10)
        ema_12 = self.tech_indicators.calculate_ema(closes, 12)
        rsi = self.tech_indicators.calculate_rsi(closes)
        
        macd, macd_signal, macd_hist = self.tech_indicators.calculate_macd(closes)
        bb_upper, bb_lower = self.tech_indicators.calculate_bollinger_bands(closes)
        stoch_k, stoch_d = self.tech_indicators.calculate_stochastic(highs, lows, closes)
        
        # Price ratios and momentum
        price_change = np.diff(closes, prepend=closes[0])
        volume_sma = self.tech_indicators.calculate_sma(volumes, 10)
        
        # Combine all features
        technical_features = np.column_stack([
            sma_5, sma_10, ema_12, rsi,
            macd, macd_signal, macd_hist,
            bb_upper, bb_lower,
            stoch_k, stoch_d,
            price_change, volume_sma,
            closes / sma_5,  # Price relative to SMA
            volumes / (volume_sma + 1e-8)  # Volume relative to average
        ])
        
        # Combine OHLCV with technical indicators
        enhanced_features = np.concatenate([ohlcv_sequence, technical_features], axis=1)
        
        return enhanced_features
    
    def forward(
        self,
        pattern_features: torch.Tensor,  # (batch, num_patterns+1)
        ohlcv_sequence: torch.Tensor     # (batch, sequence_length, 5)
    ) -> torch.Tensor:
        """
        Forward pass through enhanced hybrid model.
        
        Args:
            pattern_features: One-hot encoded pattern + confidence
            ohlcv_sequence: OHLCV candle data
        
        Returns:
            torch.Tensor: Signal probabilities (batch, 3)
        """
        batch_size = pattern_features.size(0)
        
        # ==== Branch A: Pattern Features ====
        pattern_out = self.pattern_embedding(pattern_features)  # (batch, 32)
        
        # ==== Branch B: Enhanced OHLCV + Technical Indicators ====
        # Note: In practice, technical indicators should be pre-calculated
        # For now, we'll use the OHLCV directly and let the LSTM learn patterns
        lstm_features, attention_weights = self.lstm_model(ohlcv_sequence)
        
        # ==== Advanced Fusion ====
        fusion_input = torch.cat([pattern_out, lstm_features], dim=1)
        
        # Apply attention to fusion features
        attention_weights = self.fusion_attention(fusion_input)
        attended_features = fusion_input * attention_weights
        
        # Final prediction
        logits = self.fusion_layers(attended_features)
        probabilities = torch.softmax(logits, dim=1)
        
        return probabilities
    
    def predict(
        self,
        pattern_features: np.ndarray,  # (num_patterns+1,)
        ohlcv_sequence: np.ndarray     # (30, 5)
    ) -> dict:
        """
        Inference on single sample.
        
        Args:
            pattern_features: Encoded pattern (one-hot + confidence)
            ohlcv_sequence: OHLCV data (30, 5)
        
        Returns:
            dict with keys:
                - signal: Predicted signal (BUY/SELL/HOLD)
                - confidence: Confidence score (0-1)
                - probabilities: Probabilities for each signal
        """
        # Set model to evaluation mode for inference
        self.eval()
        
        # Convert to tensors
        pattern_tensor = torch.from_numpy(pattern_features).float().unsqueeze(0).to(self.device)
        ohlcv_tensor = torch.from_numpy(ohlcv_sequence).float().unsqueeze(0).to(self.device)
        
        # Inference
        with torch.no_grad():
            output = self.forward(pattern_tensor, ohlcv_tensor)  # (1, 3)
        
        # Extract results
        probs = output[0].cpu().numpy()  # (3,)
        predicted_idx = np.argmax(probs)
        predicted_signal = self.SIGNAL_CLASSES[predicted_idx]
        confidence = float(probs[predicted_idx])
        
        return {
            "signal": predicted_signal,
            "confidence": confidence,
            "probabilities": {
                signal: float(probs[i])
                for i, signal in enumerate(self.SIGNAL_CLASSES)
            }
        }
    
    def save(self, path: str):
        """Save model weights."""
        torch.save(self.state_dict(), path)
        logger.info(f"Model saved to {path}")
    
    def load(self, path: str):
        """Load model weights."""
        if Path(path).exists():
            self.load_state_dict(torch.load(path, map_location=self.device))
            logger.info(f"Model loaded from {path}")
        else:
            raise FileNotFoundError(f"Model file not found: {path}. Please train the model first.")