from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import logging
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import routes and services
from app.api.routes import router, init_services
from app.config import config

# Create FastAPI app
app = FastAPI(
    title="Trading Signal Predictor",
    description="AI-powered trading signal prediction system combining CNN pattern detection and LSTM sequence analysis",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[config.FRONTEND_URL, "http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Include routes
app.include_router(router)

# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize services on app startup."""
    logger.info("Trading Signal Predictor starting up...")
    try:
        # Create models directory if it doesn't exist
        os.makedirs("models", exist_ok=True)
        
        # Initialize all services
        init_services()
        logger.info("Application ready to serve predictions")
    except Exception as e:
        logger.error(f"Startup error: {str(e)}")
        raise

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on app shutdown."""
    logger.info("Trading Signal Predictor shutting down...")

# Root endpoint
@app.get("/")
async def root():
    """API documentation endpoint."""
    return {
        "message": "Trading Signal Predictor API",
        "description": "AI-powered trading signal prediction system",
        "version": "1.0.0",
        "endpoints": {
            "predict": "/api/predict",
            "health": "/api/health",
            "docs": "/docs",
            "redoc": "/redoc"
        },
        "features": [
            "CNN-based pattern detection",
            "LSTM sequence analysis",
            "Market data integration",
            "Rule-based fallback"
        ]
    }

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Handle unexpected errors gracefully."""
    logger.error(f"Unhandled exception: {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "message": "Internal server error",
            "detail": str(exc) if config.DEBUG else "An unexpected error occurred"
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=config.HOST,
        port=config.PORT,
        reload=config.DEBUG,
        log_level=config.LOG_LEVEL.lower()
    )