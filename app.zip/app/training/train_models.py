#!/usr/bin/env python3
"""
Training script for both CNN pattern detection and LSTM price prediction models.

This script provides comprehensive training with:
- Data loading and preprocessing
- Model training with advanced techniques
- Validation and evaluation
- Model saving and checkpointing
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import numpy as np
import pandas as pd
from pathlib import Path
import logging
from typing import Tuple, List
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Import our models
from app.models.cnn_pattern_model import PatternDetectionModel, ImprovedPatternDetectionModel
from app.models.lstm_signal_model import HybridSignalModel, TechnicalIndicators
from app.services.image_preprocess import ImagePreprocessor
from app.services.market_data_service import MarketDataService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PatternDataset(Dataset):
    """Dataset for pattern recognition training."""
    
    def __init__(self, image_paths: List[str], labels: List[int], preprocessor: ImagePreprocessor):
        self.image_paths = image_paths
        self.labels = labels
        self.preprocessor = preprocessor
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        image_tensor = self.preprocessor.preprocess(self.image_paths[idx]).squeeze(0)
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return image_tensor, label

class SignalDataset(Dataset):
    """Dataset for signal prediction training."""
    
    def __init__(self, pattern_features: np.ndarray, ohlcv_sequences: np.ndarray, labels: np.ndarray):
        self.pattern_features = torch.FloatTensor(pattern_features)
        self.ohlcv_sequences = torch.FloatTensor(ohlcv_sequences)
        self.labels = torch.LongTensor(labels)
    
    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        return self.pattern_features[idx], self.ohlcv_sequences[idx], self.labels[idx]

class ModelTrainer:
    """Comprehensive model trainer for both CNN and LSTM models."""
    
    def __init__(self, device: str = None):
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {self.device}")
    
    def train_cnn_model(
        self,
        train_data_path: str,
        val_data_path: str = None,
        epochs: int = 100,
        batch_size: int = 32,
        learning_rate: float = 0.001,
        save_path: str = "models/best_cnn_model.pth"
    ):
        """
        Train the CNN pattern detection model.
        
        Args:
            train_data_path: Path to training data directory
            val_data_path: Path to validation data directory
            epochs: Number of training epochs
            batch_size: Batch size for training
            learning_rate: Initial learning rate
            save_path: Path to save the best model
        """
        logger.info("Starting CNN model training...")
        
        # Initialize model
        model = ImprovedPatternDetectionModel().to(self.device)
        
        # Load data
        train_loader, val_loader = self._load_pattern_data(
            train_data_path, val_data_path, batch_size
        )
        
        # Training setup
        criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=learning_rate,
            weight_decay=0.01,
            betas=(0.9, 0.999)
        )
        
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer, T_0=10, T_mult=2, eta_min=1e-6
        )
        
        # Training loop
        best_val_acc = 0.0
        patience = 15
        patience_counter = 0
        train_losses = []
        val_accuracies = []
        
        for epoch in range(epochs):
            # Training phase
            model.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0
            
            for batch_idx, (images, labels) in enumerate(train_loader):
                images, labels = images.to(self.device), labels.to(self.device)
                
                optimizer.zero_grad()
                outputs = model(images)
                loss = criterion(outputs, labels)
                loss.backward()
                
                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                
                optimizer.step()
                
                train_loss += loss.item()
                _, predicted = outputs.max(1)
                train_total += labels.size(0)
                train_correct += predicted.eq(labels).sum().item()
                
                if batch_idx % 50 == 0:
                    logger.info(f'Epoch {epoch}, Batch {batch_idx}, Loss: {loss.item():.4f}')
            
            # Validation phase
            val_acc = self._validate_cnn(model, val_loader)
            
            # Learning rate scheduling
            scheduler.step()
            
            # Record metrics
            train_losses.append(train_loss / len(train_loader))
            val_accuracies.append(val_acc)
            
            # Early stopping and model saving
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                patience_counter = 0
                # Save best model
                Path(save_path).parent.mkdir(parents=True, exist_ok=True)
                torch.save(model.state_dict(), save_path)
                logger.info(f"New best model saved with validation accuracy: {val_acc:.2f}%")
            else:
                patience_counter += 1
            
            if patience_counter >= patience:
                logger.info(f"Early stopping at epoch {epoch}")
                break
            
            train_acc = 100. * train_correct / train_total
            logger.info(f'Epoch {epoch}: Train Acc: {train_acc:.2f}%, Val Acc: {val_acc:.2f}%')
        
        # Plot training curves
        self._plot_training_curves(train_losses, val_accuracies, "CNN Training")
        
        logger.info(f"CNN training completed. Best validation accuracy: {best_val_acc:.2f}%")
        return best_val_acc
    
    def train_lstm_model(
        self,
        train_data: Tuple[np.ndarray, np.ndarray, np.ndarray],
        val_data: Tuple[np.ndarray, np.ndarray, np.ndarray] = None,
        epochs: int = 200,
        batch_size: int = 64,
        learning_rate: float = 0.001,
        save_path: str = "models/best_lstm_model.pth"
    ):
        """
        Train the LSTM signal prediction model.
        
        Args:
            train_data: Tuple of (pattern_features, ohlcv_sequences, labels)
            val_data: Validation data tuple
            epochs: Number of training epochs
            batch_size: Batch size for training
            learning_rate: Initial learning rate
            save_path: Path to save the best model
        """
        logger.info("Starting LSTM model training...")
        
        # Initialize model
        model = HybridSignalModel(
            sequence_length=60,
            lstm_hidden=128,
            lstm_layers=3,
            dropout=0.2
        ).to(self.device)
        
        # Create data loaders
        train_dataset = SignalDataset(*train_data)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        val_loader = None
        if val_data:
            val_dataset = SignalDataset(*val_data)
            val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        
        # Training setup
        criterion = nn.CrossEntropyLoss(weight=self._calculate_class_weights(train_data[2]))
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=learning_rate,
            weight_decay=0.01
        )
        
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='max', factor=0.5, patience=10, verbose=True
        )
        
        # Training loop
        best_val_acc = 0.0
        patience = 20
        patience_counter = 0
        train_losses = []
        val_accuracies = []
        
        for epoch in range(epochs):
            # Training phase
            model.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0
            
            for pattern_feat, ohlcv_seq, labels in train_loader:
                pattern_feat = pattern_feat.to(self.device)
                ohlcv_seq = ohlcv_seq.to(self.device)
                labels = labels.to(self.device)
                
                optimizer.zero_grad()
                outputs = model(pattern_feat, ohlcv_seq)
                loss = criterion(outputs, labels)
                loss.backward()
                
                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                
                optimizer.step()
                
                train_loss += loss.item()
                _, predicted = outputs.max(1)
                train_total += labels.size(0)
                train_correct += predicted.eq(labels).sum().item()
            
            # Validation phase
            val_acc = 0.0
            if val_loader:
                val_acc = self._validate_lstm(model, val_loader)
                scheduler.step(val_acc)
            
            # Record metrics
            train_losses.append(train_loss / len(train_loader))
            val_accuracies.append(val_acc)
            
            # Early stopping and model saving
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                patience_counter = 0
                # Save best model
                Path(save_path).parent.mkdir(parents=True, exist_ok=True)
                torch.save(model.state_dict(), save_path)
                logger.info(f"New best LSTM model saved with validation accuracy: {val_acc:.2f}%")
            else:
                patience_counter += 1
            
            if patience_counter >= patience:
                logger.info(f"Early stopping at epoch {epoch}")
                break
            
            train_acc = 100. * train_correct / train_total
            logger.info(f'Epoch {epoch}: Train Acc: {train_acc:.2f}%, Val Acc: {val_acc:.2f}%')
        
        # Plot training curves
        self._plot_training_curves(train_losses, val_accuracies, "LSTM Training")
        
        logger.info(f"LSTM training completed. Best validation accuracy: {best_val_acc:.2f}%")
        return best_val_acc
    
    def _load_pattern_data(self, train_path: str, val_path: str, batch_size: int):
        """Load pattern recognition data."""
        if not os.path.exists(train_path):
            raise FileNotFoundError(f"Training data path not found: {train_path}")
        
        if val_path and not os.path.exists(val_path):
            raise FileNotFoundError(f"Validation data path not found: {val_path}")
        
        # TODO: Implement actual data loading based on your dataset structure
        # Expected structure:
        # train_path/
        #   ├── class_0/  (Double Bottom)
        #   ├── class_1/  (Double Top)
        #   └── ...
        
        raise NotImplementedError(
            "Pattern data loading not implemented. Please implement based on your dataset structure."
        )
    
    def _validate_cnn(self, model, val_loader):
        """Validate CNN model."""
        model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(self.device), labels.to(self.device)
                outputs = model(images)
                _, predicted = outputs.max(1)
                total += labels.size(0)
                correct += predicted.eq(labels).sum().item()
        
        return 100. * correct / total if total > 0 else 0.0
    
    def _validate_lstm(self, model, val_loader):
        """Validate LSTM model."""
        model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for pattern_feat, ohlcv_seq, labels in val_loader:
                pattern_feat = pattern_feat.to(self.device)
                ohlcv_seq = ohlcv_seq.to(self.device)
                labels = labels.to(self.device)
                
                outputs = model(pattern_feat, ohlcv_seq)
                _, predicted = outputs.max(1)
                total += labels.size(0)
                correct += predicted.eq(labels).sum().item()
        
        return 100. * correct / total if total > 0 else 0.0
    
    def _calculate_class_weights(self, labels: np.ndarray):
        """Calculate class weights for imbalanced data."""
        unique, counts = np.unique(labels, return_counts=True)
        total = len(labels)
        weights = total / (len(unique) * counts)
        return torch.FloatTensor(weights).to(self.device)
    
    def _plot_training_curves(self, losses: List[float], accuracies: List[float], title: str):
        """Plot training curves."""
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        
        ax1.plot(losses)
        ax1.set_title(f'{title} - Loss')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        
        ax2.plot(accuracies)
        ax2.set_title(f'{title} - Validation Accuracy')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy (%)')
        
        plt.tight_layout()
        plt.savefig(f'training_curves_{title.lower().replace(" ", "_")}.png')
        plt.close()

def main():
    """Main training function."""
    parser = argparse.ArgumentParser(description='Train CNN and LSTM models')
    parser.add_argument('--model', choices=['cnn', 'lstm', 'both'], default='both',
                        help='Which model to train')
    parser.add_argument('--epochs', type=int, default=100,
                        help='Number of epochs')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='Batch size')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='Learning rate')
    parser.add_argument('--train_data', type=str, required=True,
                        help='Path to training data')
    parser.add_argument('--val_data', type=str,
                        help='Path to validation data')
    
    args = parser.parse_args()
    
    trainer = ModelTrainer()
    
    if args.model in ['cnn', 'both']:
        logger.info("Training CNN model...")
        if not args.train_data:
            raise ValueError("--train_data is required for CNN training")
        
        trainer.train_cnn_model(
            train_data_path=args.train_data,
            val_data_path=args.val_data,
            epochs=args.epochs,
            batch_size=args.batch_size,
            learning_rate=args.lr
        )
    
    if args.model in ['lstm', 'both']:
        logger.info("Training LSTM model...")
        raise NotImplementedError(
            "LSTM training requires prepared dataset with pattern features, "
            "OHLCV sequences, and signal labels. Please prepare your dataset first."
        )

if __name__ == "__main__":
    main()