import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Application configuration."""
    
    # FastAPI
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", 8000))
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    # Models
    PATTERN_MODEL_PATH = os.getenv("PATTERN_MODEL_PATH", "models/pattern_detector.pth")
    LSTM_MODEL_PATH = os.getenv("LSTM_MODEL_PATH", "models/lstm_signal_model.pth")
    USE_LSTM = os.getenv("USE_LSTM", "False").lower() == "true"
    
    # Market Data API
    MARKET_API_KEY = os.getenv("MARKET_API_KEY")
    MARKET_API_TYPE = os.getenv("MARKET_API_TYPE", "binance")
    MARKET_API_BASE_URL = os.getenv("MARKET_API_BASE_URL", "https://api.binance.com/api/v3")
    
    # Defaults
    DEFAULT_INSTRUMENT = os.getenv("DEFAULT_INSTRUMENT", "NIFTY")
    DEFAULT_TIMEFRAME = os.getenv("DEFAULT_TIMEFRAME", "5m")
    
    # Frontend
    FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")
    
    # Performance
    MAX_IMAGE_SIZE_MB = int(os.getenv("MAX_IMAGE_SIZE_MB", 10))
    INFERENCE_TIMEOUT = int(os.getenv("INFERENCE_TIMEOUT", 30))

config = Config()